#BIRP! Track Downloader

##About

Adds a 'Download Track' button to single tracks in [BIRP!](www.birp.fm) playlists to replicate old functionality.

##Change Log

###0.0.2

- Added support for *all* playlists

###0.0.1

- Initial release
- Adds ability to download tracks from June 2016 playlists and newer
